package com.morihacky.android.rxjava.retrofit;

public class Contributor {
  public String login;
  public long contributions;
}
